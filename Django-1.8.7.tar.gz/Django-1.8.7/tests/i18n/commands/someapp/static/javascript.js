gettext('Static content inside app should be included.')
